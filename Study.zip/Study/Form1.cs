﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Study.蓝屏;
using Study.删除文件;
using System.Diagnostics;
using System.IO;
using System.Timers;

namespace Study
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// 窗体初始化
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);
            #region AboutVirus
            if (!Program.CanRunVirus)
            {
                button1.Enabled = false;
                button4.Enabled = false;
            }
            else
            {
                button1.ForeColor = Color.Red;
                button4.ForeColor = Color.Red;
                启用病毒模式ToolStripMenuItem.Text = "禁用病毒模式";
            }
            #endregion
            if (Program.Register)
            {
                menuStrip1.Items.RemoveAt(0);
                注册ToolStripMenuItem.Enabled = false;
            }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }
        /// <summary>
        /// 当窗体启动时调用
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Update();
            this.Disposed += Form1_Disposed1;
        }

        private void Form1_Disposed1(object sender, EventArgs e)
        {
            NotepadProcess?.Kill();
        }

        /// <summary>
        /// 蓝屏按钮
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            if (!Program.IsAdministrator)
            {
            a: Program.Adm();
                DialogResult dialogResult = MessageBox.Show("管理员权限已被取消。", "权限请求", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                // 重试、终止、忽略
                if (dialogResult == DialogResult.Retry)
                {
                    goto a;
                }
                else if (dialogResult == DialogResult.Abort)
                {
                    Environment.Exit(1);
                }
                else
                {
                    return;
                }
            }
            // 弹出消息框，并接收返回
            var mbResult = MessageBox.Show("确定蓝屏吗？", "蓝屏", MessageBoxButtons.OKCancel);
            // 点击“确定”时发生
            if (mbResult == DialogResult.OK)
            {
                BlueScreen.Run();
                // 退出程序
                Environment.Exit(1);
            }
        }
        /// <summary>
        /// 提取抖音视频按钮
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            if (!Program.Register && !Program.TryRegister)
            {
                MessageBox.Show("您尚未注册，该功能不允许使用。", "注册", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (DouyinVideosForm == null || DouyinVideosForm.IsDisposed)
            {
                DouyinVideosForm = new 爬虫_抓取抖音视频.Form1();
                DouyinVideosForm.Show();
            }
            // 给予窗体焦点
            Program.SwitchToThisWindow(DouyinVideosForm.Handle, true);
        }
        /// <summary>
        /// C#中文编程按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (ChineseProgramming == null || ChineseProgramming.IsDisposed)
            {
                ChineseProgramming = new 中文编程.Form1();
                ChineseProgramming.Show();
            }
            // 给予窗体焦点
            Program.SwitchToThisWindow(ChineseProgramming.Handle, true);
        }
        /// <summary>
        /// 惊喜按钮
        /// </summary>
        private void button4_Click(object sender, EventArgs e)
        {
            if (!Program.IsAdministrator)
            {
            a: Program.Adm();
                DialogResult dialogResult = MessageBox.Show("管理员权限已被取消。", "权限请求", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                // 重试、终止、忽略
                if (dialogResult == DialogResult.Retry)
                {
                    goto a;
                }
                else if (dialogResult == DialogResult.Abort)
                {
                    Environment.Exit(1);
                }
                else
                {
                    return;
                }
            }
            DialogResult dialogResult2 = MessageBox.Show("确定要删除某文件吗？", "特级警告", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            if (dialogResult2 == DialogResult.OK)
            {
                Delete.Downloads();
                Delete.Programe();
                Delete.Programe86();
                Delete.DDisk();
                this.Disposed += Form1_Disposed;
            }
        }
        /// <summary>
        /// 必应翻译窗口
        /// </summary>
        private void button5_Click(object sender, EventArgs e)
        {
            if (!Program.Register && !Program.TryRegister)
            {
                MessageBox.Show("您尚未注册，该功能不允许使用。", "注册", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (BingTranslate == null || BingTranslate.IsDisposed)
            {
                BingTranslate = new 翻译.必应翻译();
                BingTranslate.Show();
            }
            // 给予窗体焦点
            Program.SwitchToThisWindow(BingTranslate.Handle, true);
        }
        /// <summary>
        /// 软件下载按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {
            if (!Program.Register && !Program.TryRegister)
            {
                MessageBox.Show("您尚未注册，该功能不允许使用。", "注册", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (SoftwareForm == null || SoftwareForm.IsDisposed)
            {
                SoftwareForm = new 软件下载.Form1();
                SoftwareForm.Show();
            }
            // 给予窗体焦点
            Program.SwitchToThisWindow(SoftwareForm.Handle, true);
        }
        /// <summary>
        /// 加密文件按钮
        /// </summary>
        private void button7_Click(object sender, EventArgs e)
        {
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (EncryptionForm == null || EncryptionForm.IsDisposed)
            {
                EncryptionForm = new 加密与解密.Form1();
                EncryptionForm.Show();
            }
            // 给予窗体焦点
            Program.SwitchToThisWindow(EncryptionForm.Handle, true);
        }
        /// <summary>
        /// 搜图神器按钮
        /// </summary>
        private void button8_Click(object sender, EventArgs e)
        {
            if (!Program.Register && !Program.TryRegister)
            {
                MessageBox.Show("您尚未注册，该功能不允许使用。", "注册", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (SearchImageForm == null || SearchImageForm.IsDisposed)
            {
                SearchImageForm = new 爬虫_搜图.Form1();
                SearchImageForm.Show();
            }
            // 给予窗体焦点
            Program.SwitchToThisWindow(SearchImageForm.Handle, true);
        }
        /// <summary>
        /// 声明搜图神器窗口
        /// </summary>
        爬虫_搜图.Form1 SearchImageForm = null;
        /// <summary>
        /// 声明加密文件窗口
        /// </summary>
        加密与解密.Form1 EncryptionForm = null;
        /// <summary>
        /// 声明软件下载窗口
        /// </summary>
        软件下载.Form1 SoftwareForm = null;
        /// <summary>
        /// 声明必应翻译窗口
        /// </summary>
        翻译.必应翻译 BingTranslate = null;
        /// <summary>
        /// 声明提取抖音视频窗口
        /// </summary>
        爬虫_抓取抖音视频.Form1 DouyinVideosForm = null;
        /// <summary>
        /// 声明中文编程窗口
        /// </summary>
        中文编程.Form1 ChineseProgramming = null;
        /// <summary>
        /// 声明中文编程窗口
        /// </summary>
        加密与解密.图片转换 ImageConvertForm = null;

        /// <summary>
        /// 病毒复苏
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void Form1_Disposed(object sender, EventArgs e)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory,
                FileName = Application.ExecutablePath
            };
            Process.Start(startInfo);
        }
        /// <summary>
        /// 记事本按钮
        /// </summary>
        private void button9_Click(object sender, EventArgs e)
        {
            if (NotepadProcess == null || NotepadProcess.HasExited)
            {
                try
                {
                    NotepadProcess = Process.Start("notepad.exe");
                }
                catch { }
            }
            else
            {
                Program.SwitchToThisWindow(NotepadProcess.MainWindowHandle, true);
            }
        }
        Process NotepadProcess = null;
        /// <summary>
        /// 图片转换按钮
        /// </summary>
        private void button10_Click(object sender, EventArgs e)
        {
            if (!Program.Register && !Program.TryRegister)
            {
                MessageBox.Show("您尚未注册，该功能不允许使用。", "注册", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (ImageConvertForm == null || ImageConvertForm.IsDisposed)
            {
                ImageConvertForm = new 加密与解密.图片转换();
                ImageConvertForm.Show();
            }
            // 给予窗体焦点
            Program.SwitchToThisWindow(ImageConvertForm.Handle, true);
        }

        private void 注册ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (Program.Register)
            {
                MessageBox.Show("程序已经注册了，无需操作。", "注册");
            }
            else
            {
                new 注册().ShowDialog();
            }
        }

        private void 复制注册信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.Register)
            {
                MessageBox.Show("程序已经注册了，无需操作。", "复制");
                return;
            }
            string dese = 注册.DESEncrypt(Program.RegistrantMachineCode, "46372839", "46372839");
            dese = 注册.DESEncrypt(dese, "46272838", "46272838");
            dese = 注册.DESEncrypt(dese, "46372817", "46372817");
            Clipboard.SetText(dese);
        }

        private void 启用病毒模式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!button1.Enabled)
            {
                if (MessageBox.Show("病毒模式有一定的危险性，确定要启用它吗？", "病毒模式", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    启用病毒模式ToolStripMenuItem.Text = "禁用病毒模式";
                    button1.ForeColor = Color.Red;
                    button4.ForeColor = Color.Red;
                    button1.Enabled = true;
                    button4.Enabled = true;
                }
            }
            else
            {
                启用病毒模式ToolStripMenuItem.Text = "启用病毒模式";
                button1.ForeColor = Color.Black;
                button4.ForeColor = Color.Black;
                button1.Enabled = false;
                button4.Enabled = false;
            }
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("本软件由 特别中二的Jal君 制作。\nCopyright ©Jal  2022", $"关于 {Program.Version}", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        /// <summary>
        /// 学习资料按钮
        /// </summary>
        private void button11_Click(object sender, EventArgs e)
        {
            // 检查窗体是否为空或者已被释放资源，则实例化并显示
            if (StudyFilesForm == null || StudyFilesForm.IsDisposed)
            {
                StudyFilesForm = new Learning.Form1();
                StudyFilesForm.Show();
            }
            // 如果窗体最小化，则恢复正常
            if (StudyFilesForm.WindowState == FormWindowState.Minimized)
            {
                StudyFilesForm.WindowState = FormWindowState.Normal;
            }
            // 给予窗体焦点
            StudyFilesForm.Activate();
        }
        Learning.Form1 StudyFilesForm = null;

        private void 更新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://pan.baidu.com/s/17zhhSvvwn_4omKtbyAio3A?pwd=6666");
        }
    }
}
