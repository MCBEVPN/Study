﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Net;
using System.Windows.Forms;
using System.Net.Http;

namespace Study.软件下载
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);
            foreach (Control item in this.Controls)
            {
                if (item.GetType() != typeof(Button) && item.GetType() != typeof(TextBox) && item.GetType() != typeof(ComboBox))
                {
                    ((Control)item).ForeColor = Color.White;
                    ((Control)item).BackColor = Color.Transparent;
                }
            }
            this.BackgroundImage = Program.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
            CheckForIllegalCrossThreadCalls = false;
            Instance();
        }
        private void Instance()
        {
            AddInstallerButton();
        }
        private async void AddInstallerButton()
        {
            HttpWebRequest httpWebRequest = WebRequest.CreateHttp("https://cdn.onlinewebfonts.com/svg/img_204460.png");
            httpWebRequest.KeepAlive = true;
            httpWebRequest.Method = "GET";
            downloadImage = Image.FromStream((await httpWebRequest.GetResponseAsync()).GetResponseStream());

            await AddImage("VS 2022", Resources.ICON_VS2022, "https://download.visualstudio.microsoft.com/download/pr/d935ace6-0b55-4ef2-8ef2-7921ad9f3d3a/cd183c1790a74a348827f38e6c384e6606a5da00f77c7bc6292563981f523ca5/vs_Community.exe", "Visual Studios 2022");
            await AddImage("Edge", Resources.ICON_EDGE_BETA, "https://go.microsoft.com/fwlink/?linkid=2084649&Channel=Beta&language=zh-cn", "Microsoft Edge Beta Channel");
            await AddImage("Edge", Resources.ICON_EDGE_DEV, "https://go.microsoft.com/fwlink/?linkid=2084649&Channel=Dev&language=zh-cn", "Microsoft Edge Dev Channel");
            await AddImage("Edge", Resources.ICON_EDGE_CAN, "https://go.microsoft.com/fwlink/?linkid=2084649&Channel=Canary&language=zh-cn", "Microsoft Edge Canary Channel");
            await AddImage("Fiddler", Resources.ICON_FIDDLER, "https://telerik-fiddler.s3.amazonaws.com/fiddler/FiddlerSetup.exe", "Fiddler Classic");
            await AddImage("微信", Resources.ICON_WECHAT, "https://pc.weixin.qq.com/", "微信电脑版", "<a class=\"download-button\" id=\"downloadButton\" href=\"(.*?)\">");
            await AddImage("QQ", Resources.ICON_QQ, "https://im.qq.com/pcqq", "QQ电脑版", "<a href=\"(.*?)\" class=\"download\">");
            await AddImage("IDM", Resources.ICON_IDM, "https://www.internetdownloadmanager.com/download.html", "Internet Download Manager", "<a class=\"cta-btn\" href=\"(.*?)\">");
            await AddImage("向日葵", Resources.ICON_SUNLOGIN, "https://dl-cdn.oray.com/sunlogin/windows/SunloginClient_12.5.1.45098_x64.exe", "向日葵个人版 for Windows");
            await AddImage("Office", Resources.ICON_OFFICE, "https://c2rsetup.officeapps.live.com/c2r/download.aspx?ProductreleaseID=ProPlus2019Retail&language=zh-CN&platform=x86&token=Problem%20obtaining%20key&TaxRegion=DB&Source=O15PKC&version=O16GA", "Microsoft Office Pro Plus 2019");
            await AddImage("Office", Resources.ICON_OFFICE, "https://c2rsetup.officeapps.live.com/c2r/download.aspx?ProductreleaseID=O365HomePremRetail&platform=Def&language=zh-CN&source=AMCFallback&version=O16GA", "Microsoft Office 365 零售家庭版（默认版本）");
            await AddImage("Office", Resources.ICON_OFFICE, "https://c2rsetup.officeapps.live.com/c2r/download.aspx?ProductreleaseID=O365HomePremRetail&platform=X86&language=zh-CN&source=AMCFallback&version=O16GA", "Microsoft Office 365 零售家庭版（x86）");
            await AddImage("Office", Resources.ICON_OFFICE, "https://c2rsetup.officeapps.live.com/c2r/download.aspx?ProductreleaseID=O365HomePremRetail&platform=X64&language=zh-CN&source=AMCFallback&version=O16GA", "Microsoft Office 365 零售家庭版（x64）");
            await AddImage("Office", Resources.ICON_OFFICE, "https://c2rsetup.officeapps.live.com/c2r/download.aspx?ProductreleaseID=O365HomePremRetail&platform=X86&language=zh-CN&source=AMCFallback&version=O16GA", "Microsoft Office 365 零售家庭版（离线安装包）");
            await AddImage("Minecraft", Resources.ICON_MINECRAFT, "https://launcher.mojang.com/download/MinecraftInstaller.exe", "Minecraft Java Edition");
            int index = 0;
            foreach (var item in pictureBoxes)
            {
                panel1.Controls.Add(item);
                if (index != 0)
                {
                    item.Location = new Point(pictureBoxes[index - 1].Location.X + 150, pictureBoxes[index - 1].Location.Y);
                }
                index++;
            }
            index = 0;
            foreach (var item in labels)
            {
                panel1.Controls.Add(item);
                item.Location = new Point(pictureBoxes[index].Location.X + 25, pictureBoxes[index].Location.Y + 200);
                index++;
            }
            progressBar1.Visible = false;
            label2.Visible = false;
            try
            {
                this.panel1.BeginInvoke(new Action(() => { panel1.Update(); }));
            }
            catch { }
        }
        List<PictureBox> pictureBoxes = new List<PictureBox>();
        Image downloadImage = null;
        List<Label> labels = new List<Label>();
        private async Task AddImage(string name, string imageUri, string fileUri, string tips, string htmlRegex)
        {
            label2.Text = "正在添加 " + tips + "...";
            await Task.Run(() =>
            {
                MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(imageUri));
                PictureBox pictureBox = new PictureBox();
                pictureBox.Image = new Bitmap(memoryStream);
                pictureBox.Size = new Size(100, 200);
                pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBox.Click += (object sender, EventArgs e) =>
                {
                    HttpWebRequest webRequest = WebRequest.CreateHttp(fileUri);
                    webRequest.KeepAlive = true;
                    webRequest.Method = "GET";
                    webRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.4985.0 Safari/537.36 Edg/102.0.1235.0";
                    StreamReader streamReader = new StreamReader(webRequest.GetResponse().GetResponseStream(), Encoding.UTF8);
                    string rDownload = streamReader.ReadToEnd();
                    string downloadUri = new Regex(htmlRegex).Match(rDownload).Groups[1].Value;
                    爬虫.WebFileInfo webFileInfo = new 爬虫.WebFileInfo();
                    爬虫.下载器窗口 form = new 爬虫.下载器窗口(100);
                    form.FormClosing += (object senderf, FormClosingEventArgs ef) =>
                    {
                        webFileInfo.StopDownload();
                        webFileInfo.CanDownload = false;
                        webFileInfo.SpeedText = "0 KB/S";
                        webFileInfo.Refesh();
                        if (DialogResult.Yes == MessageBox.Show("确认退出?\r\n如果退出将取消下载。 ", " 退出", MessageBoxButtons.YesNo))
                        {
                            webFileInfo.ExitDownload();
                        }
                        else
                        {
                            webFileInfo.CanDownload = true;
                            webFileInfo.StartDownload();
                            ef.Cancel = true;
                        }
                    };
                    form.Show();
                    webFileInfo.Downloading += () =>
                    {
                        form.Text = $"正在下载到：{webFileInfo.FileName}";
                        form.Value = webFileInfo.Value;
                        form.SpeedText = $"大小：{string.Format("{0:0.0}", (float)(webFileInfo.MaxValue / 1024000))}MB\r\n速度：{webFileInfo.SpeedText}";
                        if (webFileInfo.Value == 100)
                        {
                            form.Dispose();
                        }
                    };
                    webFileInfo.DownloadCompleted += () =>
                    {
                        if (!form.IsDisposed)
                        {
                            form.Dispose();
                        }
                    };
                    webFileInfo.DownloadFile(downloadUri, Program.DownloadPath + Path.GetFileName(downloadUri));
                };
                Image image1 = pictureBox.Image;
                pictureBox.MouseEnter += (object sender, EventArgs e) =>
                {
                    Cursor = Cursors.Hand;
                    pictureBox.Image = downloadImage ?? image1;
                };
                pictureBox.MouseLeave += (object sender, EventArgs e) =>
                {
                    Cursor = Cursors.Default;
                    pictureBox.Image = image1 ?? pictureBox.Image;
                };
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(pictureBox, "单击此处下载 " + tips);
                Label label = new Label
                {
                    Text = name,
                    Font = new Font("微软雅黑", 13F, FontStyle.Regular, GraphicsUnit.Point, 0)
                };
                pictureBoxes.Add(pictureBox);
                labels.Add(label);
            });
        }
        private async Task AddImage(string name, string imageUri, string fileUri, string tips)
        {
            label2.Text = "正在添加 " + tips + "...";
            await Task.Run(() =>
             {
                 try
                 {
                     MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(imageUri));
                     PictureBox pictureBox = new PictureBox
                     {
                         Size = new Size(100, 200),
                         SizeMode = PictureBoxSizeMode.Zoom,
                         Image = Image.FromStream(memoryStream)
                     };
                     pictureBox.Click += (object sender, EventArgs e) =>
                     {
                         爬虫.WebFileInfo webFileInfo = new 爬虫.WebFileInfo();
                         爬虫.下载器窗口 form = new 爬虫.下载器窗口(100);
                         form.FormClosing += (object senderf, FormClosingEventArgs ef) =>
                         {
                             webFileInfo.CanDownload = false;
                             webFileInfo.SpeedText = "0 KB/S";
                             webFileInfo.Refesh();
                             if (DialogResult.Yes == MessageBox.Show("确认退出?\r\n如果退出将取消下载。 ", " 退出", MessageBoxButtons.YesNo))
                             {
                                 webFileInfo.StopDownload();
                                 form.Dispose();
                             }
                             else
                             {
                                 webFileInfo.CanDownload = true;
                                 ef.Cancel = true;
                             }
                         };
                         form.Show();
                         webFileInfo.Downloading += () =>
                         {
                             form.Text = $"正在下载到：{Program.DownloadPath + Path.GetFileName(webFileInfo.FileName)}";
                             form.Value = webFileInfo.Value;
                             form.SpeedText = $"大小：{string.Format("{0:0.0}", (float)(webFileInfo.MaxValue / 1024000))}MB\r\n速度：{webFileInfo.SpeedText}";
                             if (webFileInfo.Value == 100)
                             {
                                 form.Dispose();
                             }
                         };
                         webFileInfo.DownloadCompleted += () =>
                         {
                             form.Dispose();
                         };
                         webFileInfo.DownloadFile(fileUri, Program.DownloadPath + Path.GetFileName(fileUri));
                     };
                     Image image1 = pictureBox.Image;
                     pictureBox.MouseEnter += (object sender, EventArgs e) =>
                     {
                         Cursor = Cursors.Hand;
                         pictureBox.Image = downloadImage ?? image1;
                     };
                     pictureBox.MouseLeave += (object sender, EventArgs e) =>
                     {
                         Cursor = Cursors.Default;
                         pictureBox.Image = image1 ?? pictureBox.Image;
                     };
                     ToolTip toolTip = new ToolTip();
                     toolTip.SetToolTip(pictureBox, "单机此处下载 " + tips);
                     Label label = new Label
                     {
                         Text = name,
                         Font = new Font("微软雅黑", 13F, FontStyle.Regular, GraphicsUnit.Point, 0)
                     };
                     pictureBoxes.Add(pictureBox);
                     labels.Add(label);
                 }
                 catch { }
             });
        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            label1.Location = new Point(this.Width / 2 - 195, 30);
        }
    }
}
