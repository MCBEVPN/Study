﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace Study.Learning
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            foreach (Control item in this.Controls)
            {
                if (item.GetType() != typeof(Button) && item.GetType() != typeof(TextBox) && item.GetType() != typeof(ComboBox) && item.GetType() != typeof(MenuStrip))
                {
                    ((Control)item).ForeColor = Color.White;
                    ((Control)item).BackColor = Color.Transparent;
                }
            }
            this.BackgroundImage = Program.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
            CheckForIllegalCrossThreadCalls = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start("https://pan.baidu.com/s/1q96aDsCA9js45mfFeob64w?pwd=63p1");
            Clipboard.SetText("63p1");
            MessageBox.Show("若提示提取码错误，已经帮你复制提取码了，粘贴再试试。");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process.Start("https://pan.baidu.com/s/1zm7bB6libZOA9ZwLAZ9Q1Q?pwd=pqq9");
            Clipboard.SetText("pqq9");
            MessageBox.Show("若提示提取码错误，已经帮你复制提取码了，粘贴再试试。");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process.Start("https://pan.baidu.com/s/1j5wIUm08UxTMYMOb48vo4A?pwd=vm57");
            Clipboard.SetText("vm57");
            MessageBox.Show("若提示提取码错误，已经帮你复制提取码了，粘贴再试试。");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start("https://pan.baidu.com/s/14VGgadzmDF_w6joteGwQ4Q?pwd=ne32");
            Clipboard.SetText("ne32");
            MessageBox.Show("若提示提取码错误，已经帮你复制提取码了，粘贴再试试。");
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("制        作：           特别中二的Jal君\n\n资源提供：\tHacker Over信\n\n资源审核：\t黑客零", "关于", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
